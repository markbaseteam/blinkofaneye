Who am I? 

4'000 years of asking us to know the answer to that question. 

Feedback is a gift! 🎁 So please, [treat me to any (anonymous) feedback here](http://bit.ly/3XE2Hbb).


---

I want to [quote](https://pmarca.substack.com/p/welcome) Marc Andreessen: 

"How will I write? Generally I won’t edit my copy, I won’t cite my sources, and I won’t try to be consistent. My motto is “strong views weakly held”, and you’ll see that on display here. Anything I say today I may disagree with tomorrow, in fact I frequently won’t even remember tomorrow. Ours is a moment of small, pinched, bitter minds hurling accusations of hypocrisy and inconsistency; I declare my freedom from all such criticism up front. I don’t even know what I think most of the time, why should you? Interpret all statements as questions and all declarations as explorations."

[Quoting](https://www.becktench.com/about) Beck Tench:
"I welcome conversations with friends and followers and regularly have coffee or Skype chats with complete strangers who email and ask to chat. If you'd like to think together, please send me a Twitter DM."