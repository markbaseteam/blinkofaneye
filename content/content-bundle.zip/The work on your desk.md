
>“It's the work on your desk. Do well with what you already have and more will come in.”
>― Munger

> “Think process, not product. Become a documentarian of what you do...Carving out a space for yourself online, somewhere where you can express yourself and share your work, is still one of the best possible investments you can make with your time”
> — Show Your Work by Austin Kleton



Do it.
Then show it.

[[Bet heavily]]. On this [one thing]().